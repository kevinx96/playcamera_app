# playcamera_app
Written in dart, running on Andriod studio
Yes you see where this is going, I wrote it in dart so it could be somehow compiled into iso and run on ios
